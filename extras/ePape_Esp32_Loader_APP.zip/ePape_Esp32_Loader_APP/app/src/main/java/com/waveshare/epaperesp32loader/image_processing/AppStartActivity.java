package com.waveshare.epaperesp32loader.image_processing;

import android.graphics.Bitmap;

class AppStartActivity {
    public static Bitmap originalImage;
}
